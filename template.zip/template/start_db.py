#starts Database
from template import init_db
init_db()